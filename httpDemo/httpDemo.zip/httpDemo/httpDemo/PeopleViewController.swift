//
//  ViewController.swift
//  httpDemo
//
//  Created by Jennifer Ho on 7/12/18.
//  Copyright © 2018 Rodrigo Baluyot ii. All rights reserved.
//


import UIKit
class PeopleViewController: UITableViewController {
    var people: [NSDictionary] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        getAllData(from: "http://swapi.co/api/people/")
    }
    
    func getAllData(from url: String){
        let url = URL(string: url)
        let session = URLSession.shared
        let task = session.dataTask(with: url!){
            data, response, error in
            print("in here")
            print(data ?? "no data")
            
            do {
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary {
                    let newPeople = jsonResult["results"] as! [NSDictionary]
                    self.people.append(contentsOf: newPeople)
                    
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                    if let nextUrl = jsonResult["next"] as? String {
                        
                        print(nextUrl)
                        self.getAllData(from: nextUrl)
                    }
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        // if we return - sections we won't have any sections to put our rows in
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return the count of people in our data array
        return people.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Create a generic cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        // set the default cell label to the corresponding element in the people array
        cell.textLabel?.text = people[indexPath.row]["name"] as! String
        // return the cell so that it can be rendered
        return cell
    }
}
