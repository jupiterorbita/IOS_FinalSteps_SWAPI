//
//  MovieTableViewController.swift
//  httpDemo
//
//  Created by Jennifer Ho on 7/16/18.
//  Copyright © 2018 Rodrigo Baluyot ii. All rights reserved.
//

import UIKit

class MovieTableViewController: UITableViewController {
    var films: [NSDictionary] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        getData(from: "http://swapi.co/api/films/")
        
    }
    
    func getData(from url: String) {
        StarWarsModel.getAllFilms(url: url, completionHandler:  {
            
            data, response, error in
            do {
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary {
                    let newFilms = jsonResult["results"] as! [NSDictionary]
                    
                    self.films.append(contentsOf: newFilms)
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                    if let nextUrl = jsonResult["next"] as? String {
                        print(nextUrl)
                        self.getData(from: nextUrl)
                    }
                }
            }
            catch {
                print("Something went wrong")
            }
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    
    
    
    
    
//    func getAllData(from url: String){
//        let url = URL(string: url)
//        let session = URLSession.shared
//        let task = session.dataTask(with: url!){
//            data, response, error in
//            print("in here")
//            print(data ?? "no data")
//
//            do {
//                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary {
//                    let newFilms = jsonResult["results"] as! [NSDictionary]
//                    self.films.append(contentsOf: newFilms)
//
//                    DispatchQueue.main.async {
//                        self.tableView.reloadData()
//                    }
//                    if let nextUrl = jsonResult["next"] as? String {
//
//                        print(nextUrl)
//                        self.getAllData(from: nextUrl)
//                    }
//                }
//            } catch {
//                print(error)
//            }
//        }
//        task.resume()
//    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        // if we return - sections we won't have any sections to put our rows in
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return the count of people in our data array
        return films.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Create a generic cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "FilmCell", for: indexPath)
        // set the default cell label to the corresponding element in the people array
        cell.textLabel?.text = films[indexPath.row]["title"] as! String
        // return the cell so that it can be rendered
        return cell
    }

}
